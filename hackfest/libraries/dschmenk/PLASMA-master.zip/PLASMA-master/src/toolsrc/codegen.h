typedef struct _opseq {
    int code;
    long val;
    int tag;
    int offsz;
    int type;
    struct _opseq *nextop;
} t_opseq;
#define UNARY_CODE(tkn)  ((tkn)|0x0100)
#define BINARY_CODE(tkn) ((tkn)|0x0200)
#define NEG_CODE    (0x0100|NEG_TOKEN)
#define COMP_CODE   (0x0100|COMP_TOKEN)
#define LOGIC_NOT_CODE (0x0100|LOGIC_NOT_TOKEN)
#define INC_CODE    (0x0100|INC_TOKEN)
#define DEC_CODE    (0x0100|DEC_TOKEN)
#define BPTR_CODE   (0x0100|BPTR_TOKEN)
#define WPTR_CODE   (0x0100|WPTR_TOKEN)
#define MUL_CODE    (0x0200|MUL_TOKEN)
#define DIV_CODE    (0x0200|DIV_TOKEN)
#define MOD_CODE    (0x0200|MOD_TOKEN)
#define ADD_CODE    (0x0200|ADD_TOKEN)
#define SUB_CODE    (0x0200|SUB_TOKEN)
#define SHL_CODE    (0x0200|SHL_TOKEN)
#define SHR_CODE    (0x0200|SHR_TOKEN)
#define AND_CODE    (0x0200|AND_TOKEN)
#define OR_CODE     (0x0200|OR_TOKEN)
#define EOR_CODE    (0x0200|EOR_TOKEN)
#define EQ_CODE     (0x0200|EQ_TOKEN)
#define NE_CODE     (0x0200|NE_TOKEN)
#define GE_CODE     (0x0200|GE_TOKEN)
#define LT_CODE     (0x0200|LT_TOKEN)
#define GT_CODE     (0x0200|GT_TOKEN)
#define LE_CODE     (0x0200|LE_TOKEN)
#define CONST_CODE  0x0300
#define STR_CODE    0x0301
#define LB_CODE     0x0302
#define LW_CODE     0x0303
#define LLB_CODE    0x0304
#define LLW_CODE    0x0305
#define LAB_CODE    0x0306
#define LAW_CODE    0x0307
#define SB_CODE     0x0308
#define SW_CODE     0x0309
#define SLB_CODE    0x030A
#define SLW_CODE    0x030B
#define DLB_CODE    0x030C
#define DLW_CODE    0x030D
#define SAB_CODE    0x030E
#define SAW_CODE    0x030F
#define DAB_CODE    0x0310
#define DAW_CODE    0x0311
#define CALL_CODE   0x0312
#define ICAL_CODE   0x0313
#define LADDR_CODE  0x0314
#define GADDR_CODE  0x0315
#define INDEXB_CODE 0x0316
#define INDEXW_CODE 0x0317
#define DROP_CODE   0x0318
#define DUP_CODE    0x0319
#define ADDI_CODE   0x031A
#define SUBI_CODE   0x031B
#define ANDI_CODE   0x031C
#define ORI_CODE    0x31D
#define BRNCH_CODE  0x0320
#define BRFALSE_CODE 0x0321
#define BRTRUE_CODE 0x0322
#define BREQ_CODE   0x0323
#define BRNE_CODE   0x0324
#define BRAND_CODE  0x0325
#define BROR_CODE   0x0326
#define BRLT_CODE   0x0327
#define BRGT_CODE   0x0328
#define CODETAG_CODE 0x0329
#define NOP_CODE    0x032A
#define ADDLB_CODE  0x0330
#define ADDLW_CODE  0x0331
#define ADDAB_CODE  0x0332
#define ADDAW_CODE  0x0333
#define IDXLB_CODE  0x0334
#define IDXLW_CODE  0x0335
#define IDXAB_CODE  0x0336
#define IDXAW_CODE  0x0337

#define gen_uop(seq,op)     gen_seq(seq,UNARY_CODE(op),0,0,0,0)
#define gen_op(seq,op)      gen_seq(seq,BINARY_CODE(op),0,0,0,0)
#define gen_const(seq,val)  gen_seq(seq,CONST_CODE,val,0,0,0)
#define gen_str(seq,str)    gen_seq(seq,STR_CODE,str,0,0,0)
#define gen_lcladr(seq,idx) gen_seq(seq,LADDR_CODE,0,0,idx,0)
#define gen_gbladr(seq,tag,typ) gen_seq(seq,GADDR_CODE,0,tag,0,typ)
#define gen_idxb(seq)       gen_seq(seq,ADD_CODE,0,0,0,0)
#define gen_idxw(seq)       gen_seq(seq,INDEXW_CODE,0,0,0,0)
#define gen_lb(seq)         gen_seq(seq,LB_CODE,0,0,0,0)
#define gen_lw(seq)         gen_seq(seq,LW_CODE,0,0,0,0)
#define gen_sb(seq)         gen_seq(seq,SB_CODE,0,0,0,0)
#define gen_sw(seq)         gen_seq(seq,SW_CODE,0,0,0,0)
#define gen_icall(seq)      gen_seq(seq,ICAL_CODE,0,0,0,0)
#define gen_drop(seq)       gen_seq(seq,DROP_CODE,0,0,0,0)
#define gen_brand(seq,tag)  gen_seq(seq,BRAND_CODE,0,tag,0,0)
#define gen_bror(seq,tag)   gen_seq(seq,BROR_CODE,0,tag,0,0)
#define gen_brgt(seq,tag)   gen_seq(seq,BRGT_CODE,0,tag,0,0)
#define gen_brlt(seq,tag)   gen_seq(seq,BRLT_CODE,0,tag,0,0)
#define gen_brfls(seq,tag)  gen_seq(seq,BRFALSE_CODE,0,tag,0,0)
#define gen_brtru(seq,tag)  gen_seq(seq,BRTRUE_CODE,0,tag,0,0)
#define gen_brnch(seq,tag)  gen_seq(seq,BRNCH_CODE,0,tag,0,0)
#define gen_codetag(seq,tag) gen_seq(seq, CODETAG_CODE,0,tag,0,0)
#define gen_nop(seq)        gen_seq(seq,NOP_CODE,0,0,0,0)

void emit_flags(int flags);
void emit_header(void);
void emit_trailer(void);
void emit_moddep(char *name, int len);
void emit_sysflags(int val);
void emit_bytecode_seg(void);
void emit_comment(char *s);
void emit_asm(char *s);
void emit_idlocal(char *name, int value);
void emit_idglobal(int value, int size, char *name);
void emit_idfunc(int tag, int type, char *name, int is_bytecode);
void emit_lambdafunc(int tag, char *name, int cparams, t_opseq *lambda_seq);
void emit_idconst(char *name, int value);
int emit_data(int vartype, int consttype, long constval, int constsize);
void emit_codetag(int tag);
void emit_const(int cval);
void emit_conststr(long conststr);
void emit_addi(int cval);
void emit_subi(int cval);
void emit_andi(int cval);
void emit_ori(int cval);
void emit_lb(void);
void emit_lw(void);
void emit_llb(int index);
void emit_llw(int index);
void emit_lab(int tag, int offset, int type);
void emit_law(int tag, int offset, int type);
void emit_sb(void);
void emit_sw(void);
void emit_slb(int index);
void emit_slw(int index);
void emit_dlb(int index);
void emit_dlw(int index);
void emit_sab(int tag, int offset, int type);
void emit_saw(int tag, int offset, int type);
void emit_dab(int tag, int offset, int type);
void emit_daw(int tag, int offset, int type);
void emit_call(int tag, int type);
void emit_ical(void);
void emit_localaddr(int index);
void emit_globaladdr(int tag, int offset, int type);
void emit_indexbyte(void);
void emit_indexword(void);
int emit_unaryop(t_token op);
int emit_op(t_token op);
void emit_select(int tag);
void emit_caseblock(int casecnt, int *caseof, int *casetag);
void emit_brand(int tag);
void emit_bror(int tag);
void emit_brtru(int tag);
void emit_brfls(int tag);
void emit_brne(int tag);
void emit_brnch(int tag);
void emit_brgt(int tag);
void emit_brlt(int tag);
void emit_addbrle(int tag);
void emit_incbrle(int tag);
void emit_subbrge(int tag);
void emit_decbrge(int tag);
void emit_empty(void);
void emit_drop(void);
void emit_drop2(void);
void emit_dup(void);
void emit_leave(void);
void emit_ret(void);
void emit_enter(int cparams);
void emit_start(void);
void emit_rld(void);
void emit_esd(void);
void release_seq(t_opseq *seq);
int crunch_seq(t_opseq **seq, int pass);
t_opseq *gen_seq(t_opseq *seq, int opcode, long cval, int tag, int offsz, int type);
t_opseq *cat_seq(t_opseq *seq1, t_opseq *seq2);
int emit_seq(t_opseq *seq);
int emit_pending_seq();
